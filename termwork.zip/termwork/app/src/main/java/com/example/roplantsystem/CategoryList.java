package com.example.roplantsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CategoryList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_list);
        getSupportActionBar().setTitle("CategoryList");

    }

    public void catgory_domestic(View view) {
        Intent i=new Intent(getApplicationContext(),ActivityDomestic.class);
        startActivity(i);

    }
    public void catgory_Industrial(View view) {
        Intent i=new Intent(getApplicationContext(),ActivityIndustrial.class);
        startActivity(i);
    }

    public void catgory_Domestic1(View view) {
        Intent i=new Intent(getApplicationContext(),ActivityAccessories.class);
        startActivity(i);
    }
}
