package com.example.roplantsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Login_Form extends AppCompatActivity {
    EditText email,pass;
    RegisterHelperClass db;
    //SQLiteDatabase myDB=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login__form);
        db=new RegisterHelperClass(this);
        getSupportActionBar().setTitle("Login Form");
        email=findViewById(R.id.etemail);
        pass=findViewById(R.id.etpwd);

    }

    public void btn_signupForm(View view) {
      Intent i=new Intent(getApplicationContext(),Signup_Form.class);
      startActivity(i);
    }

    public void login_btn(View view) {
        String em=email.getText().toString();
        String pwd1=pass.getText().toString();
       // background bg=new background(this);
        //bg.execute(em,pwd1);

       Boolean chkemailpwd=db.emailpassword(em,pwd1);
       if(chkemailpwd==true)
       {
          // Toast.makeText(getApplicationContext(),"Successfully login",Toast.LENGTH_LONG).show();
        Intent i=new Intent(getApplicationContext(),CategoryList.class);
        startActivity(i);

       }
       else
       {
           Toast.makeText(getApplicationContext(),"Wrong email or password",Toast.LENGTH_LONG).show();

       }

    }

}
