package com.example.roplantsystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class RegisterHelperClass extends SQLiteOpenHelper {
    private static  final  String DatabaseName="RoplantDB";
    private static final String TableName="signuptbl1";
    public RegisterHelperClass(@Nullable Context context) {
        super(context, DatabaseName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
     try {
         String create_signuptable = "CREATE TABLE " + TableName + "(firstname varchar(20),lastname varchar(20),emailid varchar(30),phoneno varchar(10),address varchar(30),spassword varchar(13));";
         db.execSQL(create_signuptable);
     }
     catch (Exception e){
        e.getMessage();
     }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists " + TableName);
        this.onCreate(db);
    }
    public  boolean insert(String fname1,String lname1,String eid1,String pno1,String addr1,String pwd1,String gender1)
    {

        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("firstname",fname1);
        values.put("lastname",lname1);
        values.put("emailid",eid1);
        values.put("phoneno",pno1);
        values.put("address",addr1);
        values.put("spassword",pwd1);
        values.put("gender",gender1);
        long ins = db.insert(TableName,null,values);
        if(ins == -1)
            return false;
        else
            return  true;
    }
   //Check Valid email exist or not
    public Boolean chkemail(String email)
    {
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from Registertbl where emailid =?",new String[]{email});
        if(cursor.getCount()>0)
            return false;
        else
            return true;

    }
    //checking the email and password from database
    public Boolean emailpassword(String email1,String password)
    {

        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from Registertbl where emailid =? and spassword=?",new String[]{email1,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;

    }
}
