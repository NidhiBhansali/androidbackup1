package com.example.roplantsystem;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Signup_Form extends AppCompatActivity {
    RegisterHelperClass db;
    EditText firstname,lastname,emailid,phno,address,spassword,cpwd;
    RadioGroup gender;
    RadioButton male,female;
    SQLiteDatabase myDB=null;
    String TableName="Registertbl";
    String Data="";
    String g="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup__form);
        getSupportActionBar().setTitle("Signup Form");
        db=new RegisterHelperClass(this);
        firstname=findViewById(R.id.etfname);
        lastname=findViewById(R.id.etlname);
        emailid=findViewById(R.id.etemail);
        phno=findViewById(R.id.etphno);
        address=findViewById(R.id.etaddress);
        spassword=findViewById(R.id.etpwd);
        cpwd=findViewById(R.id.etcpwd);
        gender=findViewById(R.id.rdgender);
        male=findViewById(R.id.rdmale);
        female=findViewById(R.id.rdfemale);
        gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i)
                {
                    case R.id.rdmale:
                        g=male.getText().toString();
                        break;
                    case R.id.rdfemale:
                        g=female.getText().toString();
                        break;
                }
            }
        });


    }
    public void move_login(View view)
    {
/*

            String fname = firstname.getText().toString();
            String lname = lastname.getText().toString();
            String eid = emailid.getText().toString();
            String pn = phno.getText().toString();
            String addr = address.getText().toString();
            String pwd = spassword.getText().toString();
            String cp = cpwd.getText().toString();
            String gen = g;
            if (fname.equals("") || lname.equals("") || eid.equals("") || pn.equals("") || addr.equals("") || pwd.equals("") || cp.equals("")) {
                Toast.makeText(getApplicationContext(), "Fields are empty", Toast.LENGTH_LONG).show();
            }
            else {
                if (pwd.equals(cp)) {
                    boolean chkemail = db.chkemail(eid);
                    if (chkemail == true) {
                        Boolean insert = db.insert(fname, lname, eid, pn, addr, pwd, gen);
                        Toast.makeText(getApplicationContext(), insert.toString(), Toast.LENGTH_LONG).show();

                        if (insert == true) {
                            Toast.makeText(getApplicationContext(), "Register Successfully", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Email Already exist", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Password Do not Match", Toast.LENGTH_LONG).show();
                }
            }
  */

        try {
            //Create Database
            myDB = this.openOrCreateDatabase("RoplantDB", Context.MODE_PRIVATE, null);
            //Create Table with Three Column(Cityname,Zipcode,District)
            myDB.execSQL("CREATE TABLE IF NOT EXISTS " + TableName + "(firstname varchar,lastname varchar,emailid varchar,phoneno varchar,address varchar,spassword varchar,gender varchar);");
            //    Toast.makeText(getApplicationContext(),"Create Database and Table Successfully..",Toast.LENGTH_LONG).show();
            String fname = firstname.getText().toString();
            String lname = lastname.getText().toString();
            String eid = emailid.getText().toString();
            String pn = phno.getText().toString();
            String addr = address.getText().toString();
            String pwd = spassword.getText().toString();
            String cp = cpwd.getText().toString();
            String gen = g;
            if (fname.equals("") || lname.equals("") || eid.equals("") || pn.equals("") || addr.equals("") || pwd.equals("") || cp.equals("")) {
                Toast.makeText(getApplicationContext(), "Fields are empty", Toast.LENGTH_LONG).show();
            } else {
                if (pwd.equals(cp)) {
                    boolean chkemail = db.chkemail(eid);
                    if (chkemail == true) {
                        myDB.execSQL("Insert into " + TableName + "(firstname,lastname,emailid,phoneno,address,spassword,gender)" + "values('" + fname + "','" + lname + "','" + eid + "','" + pn + "','" + addr + "','" + pwd + "','" + gen + "');");
                          Intent i=new Intent(getApplicationContext(),Login_Form.class);
                        startActivity(i);
                      //  Toast.makeText(getApplicationContext(), "Registerde succesfuul", Toast.LENGTH_LONG).show();

                    } else {
                        Toast.makeText(getApplicationContext(), "Email Already exist", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Password Do not Match", Toast.LENGTH_LONG).show();
                }


/*
            Toast.makeText(getApplicationContext(),"Register Successfully..",Toast.LENGTH_LONG).show();

            firstname.setText("");
            lastname.setText("");
            emailid.setText("");
            phno.setText("");
            address.setText("");
            spassword.setText("");
            cpwd.setText("");
            */
            }
        }
        catch (Exception e)
        {

            Toast.makeText(getApplicationContext(),"Not Registered successfully.." + e.getMessage(),Toast.LENGTH_LONG).show();

        }


    }


}
