package com.example.roplantsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ActivityIndustrial extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_industrial);
        getSupportActionBar().setTitle("Industrial And Commercial");

    }

    public void btnaddtocart1(View view) {
        Intent i=new Intent(getApplicationContext(),ActivityCart.class);
        startActivity(i);

    }

    public void btnaddtocart2(View view) {
    }

    public void btnaddtocart3(View view) {
    }

    public void btnaddtocart4(View view) {
    }

    public void btnaddtocart5(View view) {
    }

    public void btnaddtocart6(View view) {
    }

}
