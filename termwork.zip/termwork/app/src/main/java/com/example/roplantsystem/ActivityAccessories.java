package com.example.roplantsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ActivityAccessories extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accessories);
        getSupportActionBar().setTitle("Accessesories");


    }

    public void btnaddtocart(View view) {
        Intent i=new Intent(getApplicationContext(),ActivityCart.class);
        startActivity(i);

    }
}
